package com.solvd.airport.airplane;

public enum PowerLevels {
	Off, Low, Medium, High
}
