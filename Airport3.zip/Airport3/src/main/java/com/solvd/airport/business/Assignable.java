package com.solvd.airport.business;

import java.util.List;

import com.solvd.airport.people.Employee;

@FunctionalInterface
public interface Assignable {
	public void assign(List<Employee> from, List<Employee> to, Integer num);
}
