package com.solvd.airport.people;

public interface Payable {
	public void receivePay();
}
