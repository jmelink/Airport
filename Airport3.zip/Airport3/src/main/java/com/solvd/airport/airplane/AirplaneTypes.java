package com.solvd.airport.airplane;

public enum AirplaneTypes {
	CARGO, FIGHTER, PASSENGER;
}
