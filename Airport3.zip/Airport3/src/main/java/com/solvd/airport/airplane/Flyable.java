package com.solvd.airport.airplane;

public interface Flyable {
	public void fly();
}
